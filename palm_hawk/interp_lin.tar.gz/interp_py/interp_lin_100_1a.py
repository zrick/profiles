# -*- coding: utf-8 -*-
"""
Created on Thu Oct 28 10:33:43 2021

@author: Lenovo
"""
import numpy as np
from netCDF4 import Dataset
import os

job = 'ReD1600_100'
file = '/user/fime4215/palm/r4604/JOBS/'+job+'/OUTPUT/'+job+'_3d.000.nc'
out_file = job+'_lin_int'

#%% old grid parameters

delta = 0.20615          # =dx=dy=dz
nx = 1024
ny = 1024
nz = 256+2

Lx = delta * nx
Ly = delta * ny

dsf = 1.03              # grid stretching factor
z_stretch = 35.296       # grid stretching so that total domain height remains similar
z_stretch_new = 37.618

#%% new grid parameters

nx_new = 1536
ny_new = 1536
nz_new = 384+2

delta_new = Lx / nx_new

#%%

variables_char = ['e',
       'km',
       'kh',
       'p',
       'u',
       'v',
       'w',
       ]

z_pos_u = [True,     # variable on u levels or w levels
           True,
           True,
           True,
           True,
           True,
           False,
           ]

low_bc_dir = [False,   # variable = 0 at lower boundary
           False,
           False,
           False,
           True,
           True,
           True,
           ]

n_var = np.shape(variables_char)[0]

#%% calculate stretched grid

def grid(d,nz,dsf,z_str,dz_max): # delta, nz, dz_stretch_factor, dz_stretch_level, dz_max
    zu = np.zeros(nz)
    zw = np.zeros(nz)
    
    zu[0] = 0.
    zu[1] = 0.5 * d
    dz = d
    
    for i in range(2,nz):
        dz_below = dz
        if zu[i-1] > z_str-d:
            dz = min(dz_below * dsf,dz_max)
        zu[i] = zu[i-1] + dz
    
    zw[0] = 0.
    zw[1] = d
    
    for i in range(2,nz-1):
        zw[i] = 0.5 * (zu[i+1] + zu[i])
    
    zw[nz-1] = zw[nz-2] + dz
    
    return zu, zw

#%% grid

x = np.linspace(1,nx,nx) * delta
y = np.linspace(1,ny,ny) * delta
zu, zw = grid(delta,nz,dsf,z_stretch,6*delta)

x_new = np.linspace(1,nx_new,nx_new)*delta_new
y_new = np.linspace(1,ny_new,ny_new)*delta_new
zu_new, zw_new = grid(delta_new,nz_new,dsf,z_stretch_new,6*delta_new)

#%% read, interpolate and write

if os.path.isfile(out_file):
    os.remove(out_file)
out=open(out_file,'wb')

for m in range(n_var):
    array = np.zeros([nx,ny,nz],float)
    data = Dataset(file,'r')
    dum = data.variables[variables_char[m]][0,:,:,:]
    array = np.transpose(dum,(1,2,0))

    if low_bc_dir[m]:
        array[:,:,0] = 0.0
    else:
        array[:,:,0] = array[:,:,1]

    del(dum)

    # z-interpolation
    dum_int = np.zeros((nx,ny,nz_new))
    dum_int[:,:,0] = array[:,:,0]
    dum_int[:,:,-1] = array[:,:,-1]
    
    if z_pos_u[m]:    
        for i in range(nx):
            for j in range(ny):
                dum_int[i,j,1:nz_new-1] = np.interp(zu_new[1:nz_new-1],zu,array[i,j,:])
    else:
        for i in range(nx):
            for j in range(ny):
                dum_int[i,j,1:nz_new-1] = np.interp(zw_new[1:nz_new-1],zw,array[i,j,:])
    del(array)

    # x-interpolation
    dum_int2 = np.zeros((nx_new,ny,nz_new))
    for j in range(ny):
        for k in range(nz_new):
            dum_int2[:,j,k] = np.interp(x_new,x,dum_int[:,j,k],period=Lx)
    del(dum_int)

    # y-interpolation
    array_int = np.zeros((nx_new,ny_new,nz_new))
    for i in range(nx_new):
        for k in range(nz_new):
            array_int[i,:,k] = np.interp(y_new,y,dum_int2[i,:,k],period=Ly)
    del(dum_int2)
        
    out.write(array_int[:,:,:])
    del(array_int)

out.close()


